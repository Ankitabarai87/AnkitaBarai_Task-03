# 🎨 CSS Selector Practice Assignment - Task-03

This project is a basic practice assignment created to understand and apply fundamental concepts of HTML and CSS, including selectors, colors, and styling techniques.

---

## 📌 What I Practiced

- HTML heading tags (h1, h2, h3)
- Paragraph styling using element selectors
- Class and ID selectors in CSS
- Applying background and text colors
- Styling links (`<a>` tag) without using class or id
- Using pseudo-selectors like `:first-child`, `:nth-child`

---

## 🎯 Features

- Styled headings with class and id
- Paragraphs with different CSS selectors
- Styled paragraph with p as element selector
- Colored links with custom styles
- Ordered and unordered lists with different text colors
- Clean and simple layout for learning purpose

---

## 🛠️ Technologies Used

- HTML5  
- CSS3  

---

## ▶️ How to Run

1. Download the project  
2. Open the project folder  
3. Double-click on `index.html`  
   OR  
   Right-click → Open with Browser 

---

## 🎓 Purpose

This assignment is created to strengthen my understanding of basic web development concepts and improve my practical skills in HTML and CSS.
